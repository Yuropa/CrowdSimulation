
#ifndef Cloth_hpp
#define Cloth_hpp

#include "Ball.h"
#include "Node.h"

typedef struct {
    vec3 position;
    vec3 velocity;
    vec3 acceleration;
    vec3 normal;
} ClothPoint;

typedef struct {
    ClothPoint *p1, *p2;
    float k;
    float kd;
    float restLength;
} Spring;

class Cloth : public Node {
    float width, height;
    int segments;
    
    vector<ClothPoint> points;
    vector<Spring> springs;
    
    void updateGeometry();
public:
    Cloth(float width, float height, int segments = 20);
    ~Cloth();
    
    float getWidth();
    float getHeight();
    int getSegments();
    
    shared_ptr<Ball> physicsBall;
    
    bool attached;
    
    virtual void update(float dt);
};

#endif /* Cloth_hpp */
