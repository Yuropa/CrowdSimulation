
#ifndef Sphere_hpp
#define Sphere_hpp

#include "Geometry.h"

class Sphere : public Geometry {
    float radius;
    int horizontalSegments;
    int verticalSegments;
    
    static const int positionAttribute = 1;
    static const int normalAttribute = 2;
public:
    Sphere(float radius, int horizontalSegments = 30, int verticalSegments = 30);
    
    float getRadius();
    int getHorizontalSegments();
    int getVerticalSegments();
};

#endif /* Sphere_hpp */
