
#include "Cloth.h"
#include "Plane.h"

#define STRINGIFY(x) #x
const string clothVertexShader =
STRINGIFY(
          uniform mat4 u_modelView;
          uniform mat4 u_normal;
          uniform mat4 u_projection;
          
          attribute vec3 a_position;
          attribute vec3 a_normal;
          attribute vec2 a_texCoord;
          
          varying vec3 v_position;
          varying vec3 v_normal;
          varying vec2 v_uv;
          
          void main() {
              v_normal = (u_normal * vec4(a_normal, 0.0)).xyz;
              vec4 pos = u_modelView * vec4(a_position, 1.0);
              v_position = pos.xyz;
              v_uv = a_texCoord;
              gl_Position = u_projection * pos;
          }
          );
const string clothFragmentShader =
STRINGIFY(
          uniform sampler2D u_tex;
          
          varying vec3 v_position;
          varying vec3 v_normal;
          varying vec2 v_uv;
          void main() {
              vec3 l = normalize(vec3(100.0, 0.0, 100.0) - v_position);
              vec4 color = texture2D(u_tex, v_uv) * (0.8 * max(dot(v_normal, l), 0.0) + 0.2);
              gl_FragColor = clamp(color, 0.0, 1.0);
          }
          );

#define SpringK_Grid 1000.0
#define SpringD_Grid 2000.0
#define SpringK_Supp 1000.0
#define SpringD_Supp 2000.0

Cloth::Cloth(float width, float height, int segments) {
    this->width = width;
    this->height = height;
    this->segments = segments;
    
    attached = true;
    
    shared_ptr<Plane> plane = shared_ptr<Plane>(new Plane(width, height, segments, segments));
    setGeometry(plane);
    
    setTexture(shared_ptr<Texture>(new Texture("Textures/cloth.png")));
    
    shared_ptr<Program> clothShader(new Program());
    clothShader->bindAttribute(PositionAttributeLocation, PositionAttribute);
    clothShader->bindAttribute(NormalAttributeLocation, NormalAttribute);
    clothShader->bindAttribute(TexCoordAttributeLocation, TexCoordAttribute);
    clothShader->buildProgram(clothVertexShader, clothFragmentShader);
    setProgram(clothShader);
    
    for (int i = 0; i <= segments; i++) {
        for (int j = 0; j <= segments; j++) {
            vec3 pos = vec3(height - (float)i / (float)segments * height, (float)j / (float)segments * width - width /2.0, (float)i / (float)segments * height - height / 2.0);
            
            ClothPoint p;
            p.position = pos;
            p.velocity = vec3(0.0);
            p.acceleration = vec3(0.0);
            p.normal = vec3(1.0, 0.0, 1.0).normalize();
            points.push_back(p);
        }
    }
    
    // The grid springs
    for (int i = 0; i <= segments; i++) {
        for (int j = 0; j <= segments; j++) {
            if (i > 0) {
                Spring s;
                s.p1 = &points[(i - 1) * (segments + 1) + j];
                s.p2 = &points[(i) * (segments + 1) + j];
                s.k  = SpringK_Grid;
                s.kd = SpringD_Grid;
                s.restLength = width / (float)segments;
                springs.push_back(s);
            }
            
            if (j > 0) {
                Spring s;
                s.p1 = &points[(i) * (segments + 1) + j - 1];
                s.p2 = &points[(i) * (segments + 1) + j];
                s.k  = SpringK_Grid;
                s.kd = SpringD_Grid;
                s.restLength = height / (float)segments;
                springs.push_back(s);
            }
        }
    }
    
    // Add support springs
    for (int i = 0; i <= segments - 2; i += 2) {
        for (int j = 0; j <= segments - 2; j += 2) {
            Spring s1;
            s1.p1 = &points[(i) * (segments + 1) + j];
            s1.p2 = &points[(i + 2) * (segments + 1) + j];
            s1.k  = SpringK_Grid;
            s1.kd = SpringD_Supp;
            s1.restLength = width / (float)segments * 2.0;
            springs.push_back(s1);
            
            Spring s2;
            s2.p1 = &points[(i) * (segments + 1) + j];
            s2.p2 = &points[(i) * (segments + 1) + j + 2];
            s2.k  = SpringK_Grid;
            s2.kd = SpringD_Supp;
            s2.restLength = height / (float)segments * 2.0;
            springs.push_back(s2);
        }
    }
    
    updateGeometry();
}
Cloth::~Cloth() {
    
}

float Cloth::getWidth() {
    return width;
}
float Cloth::getHeight() {
    return height;
}
int Cloth::getSegments() {
    return segments;
}

void Cloth::update(float dt) {
    dt /= 100.0;
    for (int iter = 0; iter < 100; iter++) {
        // Copy the old velocities
        for (int i = 0; i < points.size(); i++) {
            ClothPoint *p = &points[i];
            p->acceleration = vec3(0.0);
        }
        
        // Update the spring forces
        for (int i = 0; i < springs.size(); i++) {
            Spring *s = &springs[i];
            
            // Apply the spring forces
            vec3 dir = s->p2->position - s->p1->position;
            float length = dir.length();
            float difference = (s->restLength - length);
            
            float v1 = dir.dot(s->p1->velocity);
            float v2 = dir.dot(s->p2->velocity);
            
            float force = -s->k * difference - s->kd * (v1 - v2);
            
            dir = dir.normalize();
            s->p1->acceleration = s->p1->acceleration + force * dir;
            s->p2->acceleration = s->p2->acceleration - force * dir;
        }
        
        // Integrate and update the position
        // Apply gravity and drag to the cloth points
        for (int i = 0; i < points.size(); i++) {
            ClothPoint *p = &points[i];
            
            // Gravity
            const vec3 gravity = vec3(0.0, 0.0, -2.0);
            p->acceleration = p->acceleration + gravity;
            // Drag
            const float dragAmount = 0.25 * (float)segments/width * (float)segments/height * 0.02;
            vec3 drag = -dragAmount * p->velocity.length() * p->velocity.dot(p->normal) * p->normal;
            p->acceleration = p->acceleration + drag;
            
            p->position = p->position + p->velocity * dt;
            p->velocity = p->velocity + p->acceleration * dt;
            
            if (physicsBall) {
                if ((getPosition() + p->position - physicsBall->getPosition()).length() < (physicsBall->getRadius() + 0.01)) {
                    vec3 normal = (getPosition() + p->position - physicsBall->getPosition()).normalize();
                    p->position = physicsBall->getPosition() + (0.01 + physicsBall->getRadius()) * normal - getPosition();
                    p->velocity = p->velocity - 2 * (p->velocity.dot(normal)) * normal;
                    p->velocity = p->velocity * 0.8;
                }
            }
            
            if ((getPosition() + p->position).z < 0.01) {
                p->position.z = 0.01 - getPosition().z;
                p->velocity = p->velocity - 2 * (p->velocity.dot(vec3(0.0, 0.0, 1.0))) * vec3(0.0, 0.0, 1.0);
                p->velocity = p->velocity * 0.8;
            }
        }
        
        if (attached) {
            // Pin the top and bottom to their original position
            for (int i = 0; i <= segments; i++) {
                int index = (segments + 1) * segments + i;
                points[index].position = vec3(0.0, (float)i / (float)segments * width - width /2.0, height/2.0);
                points[index].velocity = vec3(0.0);
            }
        }
    }
    
    updateGeometry();
}

void Cloth::updateGeometry() {
    shared_ptr<Geometry> geo = getGeometry();
    
    for (int i = 0; i < geo->numberOfVerticies(); i++) {
        vec3 position, normal;
        vec2 texCoord;
        geo->getVertex(i, position, normal, texCoord);
        
        position = points[i].position;
        vec3 p1 = position;
        vec3 p2, p3;
        bool flipNormal = false;
        if (i % (segments + 1) != segments) {
            p2 = points[i + 1].position;
        } else {
            p2 = points[i - 1].position;
            flipNormal = !flipNormal;
        }
        
        if (i / segments < (segments - 1)) {
            p3 = points[i + segments + 1].position;
        } else {
            p3 = points[i - segments - 1].position;
            flipNormal = !flipNormal;
        }
        
        normal = (p2 - p1).cross(p3 - p1).normalize();
        if (flipNormal) {
            normal = -normal;
        }
        
        points[i].normal = normal;
        
        geo->setVertex(i, position, normal, texCoord);
    }
    
    geo->flushVertexChanges();
}
