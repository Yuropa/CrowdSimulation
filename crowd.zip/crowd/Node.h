
#ifndef Node_hpp
#define Node_hpp

#include <vector>
#include <stdio.h>
#include "OpenGL.h"
#include "Math.h"
#include "Sphere.h"
#include "Geometry.h"

using namespace std;

class Node;

class Node : public enable_shared_from_this<Node> {
protected:
    vec3 position;
    vec3 scale;
    vec3 rotation;
    shared_ptr<Node> parent;
    vector<shared_ptr<Node>> children;
    bool needsLocalTransformUpdate;
    bool needsWorldTransformUpdate;
    bool enabled;
    mat4 localTransform;
    mat4 normalTransform;
    mat4 worldTransform;
    shared_ptr<Geometry> geo;
    shared_ptr<Program> prog;
    shared_ptr<Texture> tex;
    
    void updateLocalTransform();
    void updateWorldTransform();
    virtual void setNeedsWorldTransformUpdate();
public:
    vec3 velocity, acceleration;
    
    Node();
    ~Node();
    
    string name;
    
    void addChildNode(shared_ptr<Node> n);
    void removeFromParent();
    void removeAllChildren();
    shared_ptr<Node> childWithName(std::string name);
    
    void translateBy(vec3 translation);
    void translateTo(vec3 translation);
    vec3 getPosition();
    
    void scaleBy(vec3 scale);
    void scaleTo(vec3 scale);
    vec3 getScale();
    
    void rotateBy(vec3 rotation);
    void rotateTo(vec3 rotation);
    vec3 getRotation();
    
    void setEnabled(bool enable);
    bool isEnabled();
    
    mat4 getWorldTransform();
    
    void setGeometry(shared_ptr<Geometry> geometry);
    shared_ptr<Geometry> getGeometry();
    
    void setProgram(shared_ptr<Program> program);
    shared_ptr<Program> getProgram();
    
    void setTexture(shared_ptr<Texture> tex);
    shared_ptr<Texture> getTexture();
    
    virtual void update(float dt);
    virtual void draw(const mat4 &projectionTransform);
};

#endif /* Node_hpp */
