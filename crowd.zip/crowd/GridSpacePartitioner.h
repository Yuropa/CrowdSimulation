
#ifndef GridSpacePartitioner_hpp
#define GridSpacePartitioner_hpp

#include <iostream>
#include <vector>
#include <stdio.h>
#include "Math.h"

template <class T>
class GridSpacePartitioner {
    struct internalData {
        vec3 position;
        T data;
        
        bool operator<(const internalData& other) const {
            return position.x < other.position.x && position.y < other.position.y && position.z < other.position.z && data < other.data;
        }
        
        bool operator==(const internalData& other) const {
            return position == other.position && data == other.data;
        }
    };
    std::vector<internalData>** data;
    
    int widthDivision, heightDivision, depthDivisions;
    vec3 center;
    vec3 boundsSize;
    
    void updateData(vec3 oldCenter, vec3 oldBoundsSize, int oldWidthDivision, int oldHeightDivisions, int oldDepthDivisions) {
        std::vector<internalData>** oldData = data;
        int oldSize = oldWidthDivision * oldHeightDivisions * oldDepthDivisions;
        
        data = createBuffer(widthDivision * heightDivision * depthDivisions);
        
        for (int i = 0; i < oldSize; i++) {
            std::vector<internalData> *vec = oldData[i];
            for (typename std::vector<internalData>::iterator it = vec->begin(); it != vec->end(); it++) {
                insertData(it->position, it->data);
            }
        }
        
        freeBuffer(oldData, oldSize);
    }
    
    static std::vector<internalData>** createBuffer(int count) {
        std::vector<internalData>** buffer = (std::vector<internalData> **)malloc(count * sizeof(std::vector<internalData>*));
        for (int i = 0; i < count; i++) {
            buffer[i] = new std::vector<internalData>();
        }
        return buffer;
    }
    
    static void freeBuffer(std::vector<internalData>** buf, int size) {
        for (int i = 0; i < size; i++) {
            delete buf[i];
        }
        free(buf);
    }
public:
    GridSpacePartitioner(vec3 center, vec3 boundsSize, int widthDivision = 1, int heightDivision = 1, int depthDivisions = 1) {
        this->center = center;
        this->boundsSize = boundsSize;
        this->widthDivision = widthDivision;
        this->heightDivision = heightDivision;
        this->depthDivisions = depthDivisions;
        
        int cells = widthDivision * heightDivision * depthDivisions;
        data = createBuffer(cells);
    }
    GridSpacePartitioner(GridSpacePartitioner &partitioner) {
        center = partitioner.center;
        boundsSize = partitioner.boundsSize;
        widthDivision = partitioner.widthDivision;
        heightDivision = partitioner.heightDivision;
        depthDivisions = partitioner.depthDivisions;
        
        int cells = widthDivision * heightDivision * depthDivisions;
        data = createBuffer(cells);
        
        for (int i = 0; i < cells; i++) {
            data[i] = new std::vector<internalData>(partitioner.data[i]);
        }
    }
    ~GridSpacePartitioner() {
        freeBuffer(data, widthDivision * heightDivision * depthDivisions);
    }
    
    int getWidthDivisions() {
        return widthDivision;
    }
    void setWidthDivisions(int divisions) {
        int oldWidthDivisions = widthDivision;
        widthDivision = divisions;
        updateData(center, boundsSize, oldWidthDivisions, heightDivision, depthDivisions);
    }
    int getHeightDivisions() {
        return heightDivision;
    }
    void setHeightDivisions(int divisions) {
        int oldHeightDivisions = heightDivision;
        heightDivision = divisions;
        updateData(center, boundsSize, widthDivision, oldHeightDivisions, depthDivisions);
    }
    int getDepthDivisions() {
        return depthDivisions;
    }
    void setDepthDivisions(int divisions) {
        int oldDepthDivisions = depthDivisions;
        depthDivisions = divisions;
        updateData(center, boundsSize, widthDivision, heightDivision, oldDepthDivisions);
    }
    vec3 getCenter() {
        return center;
    }
    void setCenter(vec3 center) {
        vec3 oldCenter = this->center;
        this->center = center;
        updateData(oldCenter, boundsSize, widthDivision, heightDivision, depthDivisions);
    }
    vec3 getBoundsSize() {
        return boundsSize;
    }
    void setBoundsSize(vec3 boundsSize) {
        vec3 oldBoundsSize = this->boundsSize;
        this->boundsSize = boundsSize;
        updateData(center, oldBoundsSize, widthDivision, heightDivision, depthDivisions);
    }
    
    inline int clamp(int x, int min, int max) {
        return x < min ? min : (x > max ? max : x);
    }
    
    void insertData(vec3 position, T data) {
        internalData p = {position, data};
        
        position = position - center + boundsSize/2.0;
        int widthBin  = position.x / boundsSize.x * widthDivision;
        int heightBin = position.y / boundsSize.y * heightDivision;
        int depthBin  = position.z / boundsSize.z * depthDivisions;
        
        widthBin = clamp(widthBin, 0, widthDivision - 1);
        heightBin = clamp(heightBin, 0, heightDivision - 1);
        depthBin = clamp(depthBin, 0, depthDivisions - 1);
        
        int dataPos = widthBin * (heightDivision * depthDivisions) + heightBin * depthDivisions + depthBin;
        std::vector<internalData>*vec = this->data[dataPos];
        vec->push_back(p);
    }
    void removeData(vec3 position, T data) {
        internalData p = {position, data};
        
        position = position - center + boundsSize/2.0;
        int widthBin  = position.x / boundsSize.x * widthDivision;
        int heightBin = position.y / boundsSize.y * heightDivision;
        int depthBin  = position.z / boundsSize.z * depthDivisions;
        
        widthBin = clamp(widthBin, 0, widthDivision - 1);
        heightBin = clamp(heightBin, 0, heightDivision - 1);
        depthBin = clamp(depthBin, 0, depthDivisions - 1);
        
        int dataPos = widthBin * (heightDivision * depthDivisions) + heightBin * depthDivisions + depthBin;
        std::vector<internalData>* vec = this->data[dataPos];
        for (int i = 0; i < vec->size(); i++) {
            if (vec->at(i) == p) {
                if (vec->size() > 1) {
                    // Swap element to the end
                    vec->at(i) = vec->at(vec->size() - 1);
                }
                vec->pop_back();
                return;
            }
        }
        
        std::cout << "Element {" << position << ", " << data << "} not found in space partitioner while deleting" <<  std::endl;
    }
    void updatePosition(vec3 oldPosition, vec3 newPosition, T data) {
        bool changedBins = false;
        
        
        vec3 convertedNewPos = newPosition - center + boundsSize/2.0;
        int widthBin  = convertedNewPos.x / boundsSize.x * widthDivision;
        int heightBin = convertedNewPos.y / boundsSize.y * heightDivision;
        int depthBin  = convertedNewPos.z / boundsSize.z * depthDivisions;
        widthBin = clamp(widthBin, 0, widthDivision - 1);
        heightBin = clamp(heightBin, 0, heightDivision - 1);
        depthBin = clamp(depthBin, 0, depthDivisions - 1);
        
        vec3 convertedOldPos = oldPosition - center + boundsSize/2.0;
        int oldWidthBin  = convertedOldPos.x / boundsSize.x * widthDivision;
        int oldHeightBin = convertedOldPos.y / boundsSize.y * heightDivision;
        int oldDepthBin  = convertedOldPos.z / boundsSize.z * depthDivisions;
        oldWidthBin = clamp(oldWidthBin, 0, widthDivision - 1);
        oldHeightBin = clamp(oldHeightBin, 0, heightDivision - 1);
        oldDepthBin = clamp(oldDepthBin, 0, depthDivisions - 1);
        
        changedBins = (widthBin != oldWidthBin || heightBin || oldHeightBin || depthBin != oldDepthBin);
        
        if (changedBins) {
            removeData(oldPosition, data);
            insertData(newPosition, data);
            return;
        } else {
            int dataPos = widthBin * (heightDivision * depthDivisions) + heightBin * depthDivisions + depthBin;
            std::vector<internalData> *vec = this->data[dataPos];
            
            internalData oldData = {oldPosition, data};
            internalData newData = {newPosition, data};
            
            for (int i = 0; i < vec->size(); i++) {
                if (vec->at(i) == oldData) {
                    vec->at(i) = newData;
                    return;
                }
            }
        }
        
        std::cout << "Element {" << oldPosition << ", " << data << "} not found in space partitioner while updating position" <<  std::endl;
    }
    void updateData(vec3 position, T dataOld, T dataNew) {
        vec3 convertedNewPos = position - center + boundsSize/2.0;
        int widthBin  = convertedNewPos.x / boundsSize.x * widthDivision;
        int heightBin = convertedNewPos.y / boundsSize.y * heightDivision;
        int depthBin  = convertedNewPos.z / boundsSize.z * depthDivisions;
        widthBin = clamp(widthBin, 0, widthDivision - 1);
        heightBin = clamp(heightBin, 0, heightDivision - 1);
        depthBin = clamp(depthBin, 0, depthDivisions - 1);
        
        int dataPos = widthBin * (heightDivision * depthDivisions) + heightBin * depthDivisions + depthBin;
        std::vector<internalData> *vec = this->data[dataPos];
        
        internalData oldData = {position, dataOld};
        internalData newData = {position, dataNew};
        
        for (int i = 0; i < vec->size(); i++) {
            if (vec->at(i) == oldData) {
                vec->at(i) = newData;
                return;
            }
        }
        
        std::cout << "Element {" << position << ", " << dataOld << "} not found in space partitioner while updating data" <<  std::endl;
    }
    
    std::vector<T>* dataWithinDistance(float distance, vec3 position) {
        float distanceSqured = distance * distance;
        
        vec3 minPos = position - center + boundsSize/2.0 - vec3(distance);
        int minWidthBin  = minPos.x / boundsSize.x * widthDivision;
        int minHeightBin = minPos.y / boundsSize.y * heightDivision;
        int minDepthBin  = minPos.z / boundsSize.z * depthDivisions;
        
        minWidthBin  = clamp(minWidthBin, 0, widthDivision - 1);
        minHeightBin = clamp(minWidthBin, 0, heightDivision - 1);
        minDepthBin  = clamp(minWidthBin, 0, depthDivisions - 1);
        
        vec3 maxPos = position - center + boundsSize/2.0 + vec3(distance);
        int maxWidthBin  = maxPos.x / boundsSize.x * widthDivision;
        int maxHeightBin = maxPos.y / boundsSize.y * heightDivision;
        int maxDepthBin  = maxPos.z / boundsSize.z * depthDivisions;
        
        maxWidthBin  = clamp(maxWidthBin, 0, widthDivision - 1);
        maxHeightBin = clamp(maxHeightBin, 0, heightDivision - 1);
        maxDepthBin  = clamp(maxDepthBin, 0, depthDivisions - 1);
        
        std::vector<T>* result = new std::vector<T>();
        for (int i = minWidthBin; i <= maxWidthBin; i++) {
            for (int j = minHeightBin; j <= maxHeightBin; j++) {
                for (int k = minDepthBin; k <= maxDepthBin; k++) {
                    int dataPos = i * (heightDivision * depthDivisions) + j * depthDivisions + k;
                    
                    for (typename std::vector<internalData>::iterator it = data[dataPos]->begin(); it != data[dataPos]->end(); it++) {
                        if ((it->position - position).lengthSquared() < distanceSqured) {
                            result->push_back(it->data);
                        }
                    }
                }
            }
        }
        
        return result;
    }
};

#endif /* GridSpacePartitioner_hpp */
