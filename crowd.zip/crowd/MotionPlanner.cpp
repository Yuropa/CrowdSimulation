
#include <algorithm>
#include <map>
#include <queue>
#include "MotionPlanner.h"
#include "Plane.h"

#define STRINGIFY(x) #x
const string waypointVertexShader =
STRINGIFY(
          uniform mat4 u_modelView;
          uniform mat4 u_normal;
          uniform mat4 u_projection;
          
          attribute vec3 a_position;
          attribute vec2 a_texCoord;
          
          varying vec2 v_uv;
          
          void main() {
              v_uv = a_texCoord;
              gl_Position = u_projection * u_modelView * vec4(a_position, 1.0);
          }
          );
const string waypointFragmentShader =
STRINGIFY(
          uniform sampler2D u_tex;
          
          varying vec2 v_uv;
          void main() {
              gl_FragColor = texture2D(u_tex, v_uv);
          }
          );

const string obstacleVertexShader =
STRINGIFY(
          uniform mat4 u_modelView;
          uniform mat4 u_normal;
          uniform mat4 u_projection;
          
          attribute vec3 a_position;
          attribute vec3 a_normal;
          
          varying vec3 v_position;
          varying vec3 v_normal;
          
          void main() {
              v_normal = (u_normal * vec4(a_normal, 0.0)).xyz;
              vec4 pos = u_modelView * vec4(a_position, 1.0);
              v_position = pos.xyz;
              gl_Position = u_projection * pos;
          }
          );
const string obstacleFragmentShader =
STRINGIFY(
          varying vec3 v_position;
          varying vec3 v_normal;
          void main() {
              vec3 l = normalize(vec3(100.0, 0.0, 100.0) - v_position);
              vec4 color = vec4(0.2, 1.0, 0.6, 1.0) * (0.8 * max(dot(v_normal, l), 0.0) + 0.2);
              gl_FragColor = clamp(color, 0.0, 1.0);
          }
          );

#define STRINGIFY(x) #x
const string agentVertexShader =
STRINGIFY(
          uniform mat4 u_modelView;
          uniform mat4 u_normal;
          uniform mat4 u_projection;
          
          attribute vec3 a_position;
          attribute vec3 a_normal;
          
          varying vec3 v_position;
          varying vec3 v_normal;
          
          void main() {
              v_normal = (u_normal * vec4(a_normal, 0.0)).xyz;
              vec4 pos = u_modelView * vec4(a_position, 1.0);
              v_position = pos.xyz;
              gl_Position = u_projection * pos;
          }
          );
const string agentFragmentShader =
STRINGIFY(
          varying vec3 v_position;
          varying vec3 v_normal;
          void main() {
              vec3 l = normalize(vec3(100.0, 0.0, 100.0) - v_position);
              vec4 color = vec4(1.0, 0.2, 0.6, 1.0) * (0.8 * max(dot(v_normal, l), 0.0) + 0.2);
              gl_FragColor = clamp(color, 0.0, 1.0);
          }
          );


shared_ptr<Geometry> MotionObstacle::getGeometry() {
    return nullptr;
}
vec2 MotionObstacle::getPosition() {
    return vec2(0.0);
}
bool MotionObstacle::containsPoint(vec2 point) {
    return false;
}
bool MotionObstacle::intersectLineSegment(vec2 start, vec2 end) {
    return false;
}
void MotionObstacle::addExtent(float radius) {
    
}

vec2 MotionObstacle::projectPoint(vec2 point, float radius) {
    return point;
}



CircleObstacle::CircleObstacle(vec2 position, float radius) {
    this->position = position;
    this->radius = radius;
}

float CircleObstacle::getRadius() {
    return radius;
}
vec2 CircleObstacle::getPosition() {
    return position;
}

shared_ptr<Geometry> CircleObstacle::getGeometry() {
    return shared_ptr<Sphere>(new Sphere(radius * 0.75));
}
bool CircleObstacle::containsPoint(vec2 point) {
    return (point - position).length() < radius;
}
bool CircleObstacle::intersectLineSegment(vec2 start, vec2 end) {
    
    vec2 p = start - getPosition();
    vec2 v = end - start;
    
    float a = v.dot(v);
    float b = 2*p.dot(v);
    float c = p.dot(p) - getRadius() * getRadius();\
    
    float discriminant = b*b - 4*a*c;
    if (discriminant < 0.0) {
        // No solutions
        return false;
    }
    
    // Solve for the two times using the quadratic formula
    float solution1 = (-b + sqrt(discriminant))/(2 * a);
    float solution2 = (-b - sqrt(discriminant))/(2 * a);
    
    if (solution1 >= 0.0 && solution1 <= 1.0) {
        return true;
    }
    if (solution2 >= 0.0 && solution2 <= 1.0) {
        return true;
    }
    
    return false;
}
void CircleObstacle::addExtent(float radius) {
    this->radius += radius;
}
vec2 CircleObstacle::projectPoint(vec2 point, float radius) {
    vec2 dir = (point - getPosition()).normalize();
    
    return getPosition() + dir * (this->radius);
}

CapsuleObstacle::CapsuleObstacle(vec2 startPosition, vec2 endPosition, float radius) {
    start = startPosition;
    end = endPosition;
    this->radius = radius;
}

float CapsuleObstacle::getRadius() {
    return radius;
}
vec2 CapsuleObstacle::getPosition() {
    return 0.5 * (start + end);
}
vec2 CapsuleObstacle::getStartPosition() {
    return start;
}
vec2 CapsuleObstacle::getEndPosition() {
    return end;
}

shared_ptr<Geometry> CapsuleObstacle::getGeometry() {
    shared_ptr<Geometry> geometry = shared_ptr<Geometry>(new Geometry());
    
    float radius = 0.8 * this->radius;
    float distance = (end - start).length() / 2.0;
    vec2 direction = (end - start).normalize();
    vec2 crossDirection = vec2(direction.y, -direction.x) * radius;
    
    vec3 normal = vec3(0.0, 0.0, 1.0);
    
    vec2 pos = -direction * (radius + distance) - crossDirection;
    geometry->addVertex(vec3(pos.x, pos.y, 0.0), normal, vec2(0.0, 0.0));
    
    pos = - direction * (radius + distance) + crossDirection;
    geometry->addVertex(vec3(pos.x, pos.y, 0.0), normal, vec2(0.0, 1.0));
    
    pos = direction * (radius + distance) - crossDirection;
    geometry->addVertex(vec3(pos.x, pos.y, 0.0), normal, vec2(1.0, 0.0));
    
    pos = direction * (radius + distance) + crossDirection;
    geometry->addVertex(vec3(pos.x, pos.y, 0.0), normal, vec2(1.0, 1.0));
    
    
    geometry->addIndex(0);
    geometry->addIndex(1);
    geometry->addIndex(2);
    
    geometry->addIndex(1);
    geometry->addIndex(3);
    geometry->addIndex(2);
    
    geometry->prepareForRendering();
    
    return geometry;
}
bool CapsuleObstacle::containsPoint(vec2 point) {
    // Adapted from http://stackoverflow.com/questions/849211/shortest-distance-between-a-point-and-a-line-segment
    vec2 difference = start - end;
    float l2 = difference.dot(difference);
    
    float t = (point - start).dot(point - end) / l2;
    t = t > 1.0 ? 1.0 : (t < 0.0 ? 0.0 : t);
    vec2 projection = start + t * (end - start);
    return point.distanceTo(projection) < radius;
}
bool CapsuleObstacle::intersectLineSegment(vec2 start, vec2 end) {
    // Adpated from http://geomalgorithms.com/a07-_distance.html
    vec2 u = this->end - this->start;
    vec2 v = end - start;
    vec2 w = this->start - start;
    
    float    a = u.dot(u);         // always >= 0
    float    b = u.dot(v);
    float    c = v.dot(v);         // always >= 0
    float    d = u.dot(w);
    float    e = v.dot(w);
    float    D = a*c - b*b;        // always >= 0
    float    sc, sN, sD = D;       // sc = sN / sD, default sD = D >= 0
    float    tc, tN, tD = D;       // tc = tN / tD, default tD = D >= 0
    
    // compute the line parameters of the two closest points
    if (D < 0.00001) { // the lines are almost parallel
        sN = 0.0;         // force using point P0 on segment S1
        sD = 1.0;         // to prevent possible division by 0.0 later
        tN = e;
        tD = c;
    }
    else {                 // get the closest points on the infinite lines
        sN = (b*e - c*d);
        tN = (a*e - b*d);
        if (sN < 0.0) {        // sc < 0 => the s=0 edge is visible
            sN = 0.0;
            tN = e;
            tD = c;
        }
        else if (sN > sD) {  // sc > 1  => the s=1 edge is visible
            sN = sD;
            tN = e + b;
            tD = c;
        }
    }
    
    if (tN < 0.0) {            // tc < 0 => the t=0 edge is visible
        tN = 0.0;
        // recompute sc for this edge
        if (-d < 0.0)
            sN = 0.0;
        else if (-d > a)
            sN = sD;
        else {
            sN = -d;
            sD = a;
        }
    }
    else if (tN > tD) {      // tc > 1  => the t=1 edge is visible
        tN = tD;
        // recompute sc for this edge
        if ((-d + b) < 0.0)
            sN = 0;
        else if ((-d + b) > a)
            sN = sD;
        else {
            sN = (-d +  b);
            sD = a;
        }
    }
    // finally do the division to get sc and tc
    sc = (abs(sN) < 0.00001 ? 0.0 : sN / sD);
    tc = (abs(tN) < 0.00001 ? 0.0 : tN / tD);
    
    // get the difference of the two closest points
    vec2   dP = w + (sc * u) - (tc * v);  // =  S1(sc) - S2(tc)
    
    return dP.length() < radius;
}
void CapsuleObstacle::addExtent(float radius) {
    this->radius += radius;
}
vec2 CapsuleObstacle::projectPoint(vec2 point, float radius) {
    // Adapted from http://stackoverflow.com/questions/849211/shortest-distance-between-a-point-and-a-line-segment
    vec2 difference = start - end;
    float l2 = difference.dot(difference);
    
    float t = (point - start).dot(point - end) / l2;
    t = t > 1.0 ? 1.0 : (t < 0.0 ? 0.0 : t);
    vec2 projection = start + t * (end - start);
    return projection;
}

#define PointSize 0.5

MotionPlanner::MotionPlanner(float width, float height) {
    this->width = width;
    this->height = height;
    routePlanned = false;
    
    obstalProgram = shared_ptr<Program>(new Program());
    obstalProgram->bindAttribute(PositionAttributeLocation, PositionAttribute);
    obstalProgram->bindAttribute(NormalAttributeLocation,   NormalAttribute);
    obstalProgram->buildProgram(obstacleVertexShader, obstacleFragmentShader);
    
    waypointProgram = shared_ptr<Program>(new Program());
    waypointProgram->bindAttribute(PositionAttributeLocation, PositionAttribute);
    waypointProgram->bindAttribute(TexCoordAttributeLocation, TexCoordAttribute);
    waypointProgram->buildProgram(waypointVertexShader, waypointFragmentShader);
    
    waypointTexture = shared_ptr<Texture>(new Texture("Textures/Waypoint.png"));
    waypointGeometry = shared_ptr<Geometry>(new Plane(PointSize, PointSize));
    
    setEnableDebug(false);
}

void MotionPlanner::addAgent(vec2 position) {
    shared_ptr<Node> agent = shared_ptr<Node>(new Node());
    agent->translateTo(vec3(position.x, position.y, 0.0));
    
    shared_ptr<Program> agentProgram = shared_ptr<Program>(new Program());
    agentProgram->bindAttribute(PositionAttributeLocation, PositionAttribute);
    agentProgram->bindAttribute(NormalAttributeLocation,   NormalAttribute);
    agentProgram->buildProgram(agentVertexShader, agentFragmentShader);
    agent->setProgram(agentProgram);
    
    agent->setGeometry(shared_ptr<Geometry>(new Sphere(PointSize/2.0)));
    addChildNode(agent);
    
    agents.push_back(agent);
    targetWaypoints.push_back(vector<vec2>());
}

void MotionPlanner::setEndPosition(vec2 pos) {
    vec3 position = vec3(pos.x, pos.y, 0.0);
    if (!endIndicator) {
        endIndicator = shared_ptr<Node>(new Node());
        endIndicator->setProgram(waypointProgram);
        endIndicator->setTexture(shared_ptr<Texture>(new Texture("Textures/End.png")));
        endIndicator->setGeometry(waypointGeometry);
    }
    endIndicator->translateTo(position);
}
vec2 MotionPlanner::getEndPosition() {
    vec3 position = endIndicator->getPosition();
    return vec2(position.x, position.y);
}

float randomFloat() {
    return (float)rand() / (float)RAND_MAX;
}

void MotionPlanner::generateRoute() {
    for (int i = 0; i < obsticals.size(); i++) {
        obsticals[i]->addExtent(PointSize/2.0);
    }
    
    waypoints.clear();
    for (int i = 0; i < width/2; i++) {
        for (int j = 0; j < height/2; j++) {
            bool validPoint = true;
            vec2 point = vec2(randomFloat() * width - width / 2.0, randomFloat() * height - height / 2.0);
            
            for (int k = 0; k < obsticals.size(); k++) {
                if (obsticals[k]->containsPoint(point)) {
                    validPoint = false;
                    break;
                }
            }
            
            if (validPoint) {
                PathNode node;
                node.node = (int)waypoints.size();
                node.parent = NULL;
                node.cost = INFINITY;
                node.position = point;
                node.heristic = node.position.distanceTo(getEndPosition());
                
                waypoints.push_back(node);
            }
        }
    }
    
    // Add end point
    PathNode endNode;
    endNode.node = (int)waypoints.size();
    endNode.parent = NULL;
    endNode.cost = INFINITY;
    endNode.position = getEndPosition();
    endNode.heristic = 0.0;
    waypoints.push_back(endNode);
    
    
    connections.clear();
    for (int i = 0; i < (int)waypoints.size(); i++) {
        for (int j = i + 1; j < waypoints.size(); j++) {
            vec2 start = waypoints[i].position;
            vec2 end = waypoints[j].position;
            
            bool isValidConnection = true;
            
            for (int k = 0; k < obsticals.size(); k++) {
                if (obsticals[k]->intersectLineSegment(start, end)) {
                    isValidConnection = false;
                    break;
                }
            }
            
            if (isValidConnection) {
                if (connections.count(i) <= 0) {
                    connections[i] = new vector<int>();
                }
                connections[i]->push_back(j);
                
                if (connections.count(j) <= 0) {
                    connections[j] = new vector<int>();
                }
                connections[j]->push_back(i);
            }
        }
    }
    
    routePlanned = true;
}


PathNodeCompare pathNodeCompare;
void MotionPlanner::planRouteForAgent(int index) {
    vector<PathNode*> queue;
    
    shared_ptr<Node> agent = agents[index];
    
    // Add the starting location
    PathNode start;
    start.node = (int)-1;
    start.parent = NULL;
    start.cost = 0.0;
    vec3 agentPosition = agent->getPosition();
    start.position = vec2(agentPosition.x, agentPosition.y);
    start.heristic = 0.0;
    
    vector<int>* startConnections = new vector<int>();
    
    // Get all the connections from the start node
    for (int j = 0; j < waypoints.size(); j++) {
        vec2 end = waypoints[j].position;
        
        bool isValidConnection = true;
        
        for (int k = 0; k < obsticals.size(); k++) {
            if (obsticals[k]->intersectLineSegment(start.position, end) && !obsticals[k]->containsPoint(start.position)) {
                isValidConnection = false;
                break;
            }
        }
        
        if (isValidConnection) {
            startConnections->push_back(j);
        }
    }
    
    queue.push_back(&start);
    
    for (int i = 0; i < waypoints.size(); i++) {
        queue.push_back(&waypoints[i]);
    }
    
    // Perform A*
    while (queue.size() > 0) {
        vector<PathNode*>::iterator n = min_element(queue.begin(), queue.end(), pathNodeCompare);
        PathNode* node = *n;
        
        vector<int> *neighbors;
        if (node->node == -1) {
            neighbors = startConnections;
        } else {
            neighbors = connections[node->node];
        }
        
        if (neighbors) {
            for (vector<int>::iterator it = neighbors->begin(); it != neighbors->end(); it++) {
                PathNode *neighbor = &waypoints[*it];
                float alt = node->cost + node->costToNode(neighbor);
                if (alt < neighbor->cost) {
                    neighbor->cost = alt;
                    neighbor->parent = &*node;
                }
            }
        }
        queue.erase(n);
    }
    
    targetWaypoints.at(index).clear();
    
    // Have either completed path or no path at all
    bool foundCompletePath = false;
    PathNode *traverseNode = &waypoints.back();
    while (traverseNode->parent != NULL) {
        vec2 end = traverseNode->position;
        
        if (traverseNode->parent->node == -1) {
            foundCompletePath = true;
        }
        targetWaypoints.at(index).push_back(end);
        traverseNode = traverseNode->parent;
    }
    
    // Clean up the A* intermediate stuff
    for (int i = 0; i < waypoints.size(); i++) {
        waypoints[i].parent = NULL;
        waypoints[i].cost = INFINITY;
    }
}

vec2 agentEnergy(vec2 pa, vec2 pb, vec2 va, vec2 vb, float ra, float rb) {
    vec2 w = pb - pa;
    vec2 v = va - vb;
    float radius = ra + rb;
    float a = v.dot(v);
    float b = w.dot(v);
    float c = w.dot(w) - radius*radius;
    float discr = b*b - a*c;
    if (discr < 0) {
        return vec2(0.0);
    }
    discr = sqrt(discr);
    float t = (b - discr) / a;
    
    if (t < 0) {
        return vec2(0.0);
    }
    
    float k = 0.4;
    return k*(v - (v*b - w*a)/(discr))/(a*t*t)*(2/t);
}

void MotionPlanner::updateAgent(float dt, int index) {
    shared_ptr<Node> agent = agents.at(index);
    vec2 pos = vec2(agent->getPosition().x, agent->getPosition().y);
    
    // Perform path smoothing, and check that all the path is still valid
    if (targetWaypoints.at(index).size() > 1) {
        // There is another way point for us to move to
        bool intersection = false;
        for (int i = 0; i < obsticals.size(); i++) {
            if (obsticals[i]->intersectLineSegment(pos, targetWaypoints.at(index).at(targetWaypoints.at(index).size() - 2))) {
                intersection = true;
                break;
            }
        }
        
        if (!intersection) {
            targetWaypoints.at(index).pop_back();
        } else {
            // Make sure that we can get to the first waypoint
            bool intersectionToFirstWayPoint = false;
            for (int i = 0; i < obsticals.size(); i++) {
                if (obsticals[i]->intersectLineSegment(pos, targetWaypoints.at(index).back())) {
                    intersectionToFirstWayPoint = true;
                    break;
                }
            }
            if (intersectionToFirstWayPoint) {
                targetWaypoints.at(index).clear();
            }
        }
    } else if (targetWaypoints.at(index).size() == 1) {
        // Make sure that we can get to the first waypoint
        bool intersectionToFirstWayPoint = false;
        for (int i = 0; i < obsticals.size(); i++) {
            if (obsticals[i]->intersectLineSegment(pos, targetWaypoints.at(index).back())) {
                intersectionToFirstWayPoint = true;
                break;
            }
        }
        if (intersectionToFirstWayPoint) {
            targetWaypoints.at(index).clear();
        }
    }
    
    // Make sure there is a path
    if (targetWaypoints.at(index).size() == 0) {
        // No path planned, so we need to plan it
        planRouteForAgent(index);
    }
    
    // Since we are in a crowd, we will never reach the goal completely, but the group will gather around there
    vec2 dir = pos - targetWaypoints.at(index).back();
    dir = -200.0 * dir.normalize() * dt;
    vec2 force = vec2(0.0);
    
    
    
    for (int i = 0; i < agents.size(); i++) {
        if (i == index) {
            continue;
        }
        
        vec3 positionB = agents[i]->getPosition();
        vec2 difference = pos - vec2(positionB.x, positionB.y);
        
        if (difference.length() < PointSize * 3.0) {
            force = force + difference.normalize() * 1.0 / (difference.length() * difference.length());
        }
    }
    
//    for (int i = 0; i < obsticals.size(); i++) {
//        float factor = 1.0 / (dir.length());
//        if (factor > 100.0) {
//            factor = 100.0;
//        }
//        vec2 dir = (obsticals[i]->projectPoint(pos, PointSize) - pos);
//        force = force + dir.normalize() * factor;
//    }
    
    pos = pos + (dir + force) * dt;
    
    agent->translateTo(vec3(pos.x, pos.y, 0.0));
}

void MotionPlanner::setEnableDebug(bool flag) {
    showDebug = flag;
}

bool MotionPlanner::enableDebug() {
    return showDebug;
}

void MotionPlanner::addObstacle(shared_ptr<MotionObstacle> obstacle) {
    obsticals.push_back(obstacle);
    
    shared_ptr<Node> node = shared_ptr<Node>(new Node());
    node->setGeometry(obstacle->getGeometry());
    vec2 pos = obstacle->getPosition();
    node->translateBy(vec3(pos.x, pos.y, 0.0));
    node->setProgram(obstalProgram);
    addChildNode(node);
}

void MotionPlanner::update(float dt) {
    if (routePlanned) {
        for (int i = 0; i < agents.size(); i++) {
            updateAgent(dt, i);
        }
    }
}


void MotionPlanner::draw(const mat4 &projectionTransform) {
    
    glDisable(GL_DEPTH_TEST);
    glEnable(GL_BLEND);
    glBlendFunc(GL_ONE, GL_ONE);
    
    endIndicator->draw(projectionTransform);
    
    glDisable(GL_BLEND);
    glEnable(GL_DEPTH_TEST);
    Node::draw(projectionTransform);
}
