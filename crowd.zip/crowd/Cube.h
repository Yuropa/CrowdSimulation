
#ifndef Cube_hpp
#define Cube_hpp

#include "Geometry.h"

class Cube : public Geometry {
    float width, height, depth;
    int widthSegments;
    int heightSegments;
    int depthSegments;
    
    static const int positionAttribute = 1;
    static const int normalAttribute = 2;
public:
    Cube(float width, float height, float depth, int widthSegments = 1, int heightSegments = 1, int depthSegments = 1);
    
    float getWidth();
    float getHeight();
    float getDepth();
    int getWidthSegments();
    int getHeightSegments();
    int getDepthSegments();
};

#endif /* Cube_hpp */
