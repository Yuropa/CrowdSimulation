
#ifndef VEC3_H
#define VEC3_H

#include <cmath>
#include <iostream>

class vec3 {
public:
    float x, y, z;
    
    inline vec3(float x, float y, float z) {
        this->x = x;
        this->y = y;
        this->z = z;
    }
    
    inline vec3(float value) {
        x = y = z = value;
    }
    
    inline vec3() : vec3(0.0) {}
    
    inline vec3 operator+(vec3 vec) const {
        return vec3(x + vec.x, y + vec.y, z + vec.z);
    }
    
    inline vec3 operator-() const {
        return vec3(-x, -y, -z);
    }
    
    inline vec3 operator-(vec3 vec) const {
        return vec3(x - vec.x, y - vec.y, z - vec.z);
    }
    
    inline vec3 operator*(vec3 vec) const {
        return vec3(x * vec.x, y * vec.y, z * vec.z);
    }
    
    inline vec3 operator/(vec3 vec) const {
        return vec3(x / vec.x, y / vec.y, z / vec.z);
    }
    
    inline float dot(vec3 vec) const {
        return x*vec.x + y*vec.y + z*vec.z;
    }
    
    inline vec3 cross(vec3 vec) const {
        return vec3(y*vec.z - z*vec.y, z*vec.x - x*vec.z, x*vec.y - y*vec.x);
    }
    
    inline float length() const {
        float value = dot(*this);
        if (value <= 0.0) {
            return 0.0;
        } else {
            return sqrtf(value);
        }
    }
    
    inline float lengthSquared() const {
        return dot(*this);
    }
    
    inline vec3 normalize() const {
        float l = length();
        return vec3(x/l, y/l, z/l);
    }
    
    inline float distanceTo(vec3 v) const {
        return (v - *this).length();
    }
    
    inline bool operator==(vec3 v) const {
        return  x == v.x && y == v.y && z == v.z;
    }
    
    inline vec3 lerp(vec3 end, float t) {
        return *this * (1.0 - t) + end * t;
    }
};

inline vec3 operator/(vec3 v, float a) {
    return vec3(v.x/a, v.y/a, v.z/a);
}

inline vec3 operator*(vec3 v, float a) {
    return vec3(v.x*a, v.y*a, v.z*a);
}

inline vec3 operator*(float a, vec3 v) {
    return vec3(v.x*a, v.y*a, v.z*a);
}

inline std::ostream & operator<<(std::ostream & os, const vec3 & v)
{
    os << "<" << v.x << ", " << v.y << ", " << v.z << ">" << std::endl;
    return os;
}

#endif