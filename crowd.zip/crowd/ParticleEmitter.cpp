
#include "ParticleEmitter.h"

#define BUFFER_OFFSET(i) ((char *)NULL + (i))

#define STRINGIFY(x) #x
const std::string vertexShader =
STRINGIFY(
          uniform mat4 u_modelView;
          uniform mat4 u_normal;
          uniform mat4 u_projection;
          
          attribute vec3 a_position;
          attribute vec3 a_normal;
          attribute vec3 a_offset;
          attribute vec4 a_ambientColor;
          attribute vec2 a_texCoord;
          attribute float a_diffuseAmount;
          
          varying vec3 v_position;
          varying vec3 v_normal;
          varying vec4 v_diffuseColor;
          varying vec4 v_ambientColor;
          varying vec2 v_texCoord;
          void main() {
              v_ambientColor = a_ambientColor;
              v_diffuseColor = a_ambientColor * a_diffuseAmount;
              v_texCoord = a_texCoord;
              
              v_normal = (u_normal * vec4(a_normal, 0.0)).xyz;
              vec4 pos = u_modelView * vec4(a_position + a_offset, 1.0);
              v_position = pos.xyz;
              gl_Position = u_projection * pos;
          }
);
const std::string fragmentShader =
STRINGIFY(
          uniform sampler2D u_tex;
          
          varying vec3 v_position;
          varying vec3 v_normal;
          varying vec4 v_diffuseColor;
          varying vec4 v_ambientColor;
          varying vec2 v_texCoord;
          void main() {
              vec3 l = normalize(vec3(0.0, 0.0, 100.0) - v_position);
              vec4 diffuse = v_diffuseColor * (max(dot(v_normal, l), 0.0));
              vec4 ambient = v_ambientColor * texture2D(u_tex, v_texCoord);
              gl_FragColor = clamp(diffuse + ambient, 0.0, 1.0);
          }
);

const GLint ParticlePosition      = TexCoordAttributeLocation + 1;
const GLint ParticleAmbientColor  = ParticlePosition + 1;
const GLint ParticleDiffuseAmount = ParticleAmbientColor + 1;

ParticleEmitter::ParticleEmitter(float radius) : particlesGridSpace(vec3(0.0, 0.0, 0.0), vec3(1.0, 1.0, 1.0)) {
    this->radius = radius;
    
    shared_ptr<Program> program = shared_ptr<Program>(new Program());
    program->bindAttribute(PositionAttributeLocation, PositionAttribute);
    program->bindAttribute(NormalAttributeLocation, NormalAttribute);
    
    program->bindAttribute(ParticlePosition, "a_offset");
    program->bindAttribute(ParticleAmbientColor, "a_ambientColor");
    program->bindAttribute(ParticleDiffuseAmount, "a_diffuseAmount");
    
    const unsigned char whiteData[] = {255, 255, 255, 255};
    whiteTexture = shared_ptr<Texture>(new Texture(1, 1, (void *)whiteData));
    
    program->buildProgram(vertexShader, fragmentShader);
    setProgram(program);
    
    setGeometry(shared_ptr<Sphere>(new Sphere(0.03, 10, 10)));
    
    glGenBuffers(1, &positionVBO);
    GetGLError();
}

ParticleEmitter::~ParticleEmitter() {
    glDeleteBuffers(1, &positionVBO);
}

void ParticleEmitter::setInitialVelocity(vec3 initialVelocity) {
    this->initialVelocity = initialVelocity;
}
vec3 ParticleEmitter::getInitialVelocity() {
    return initialVelocity;
}

void ParticleEmitter::setParticleLifetime(float particleLifetime) {
    this->particleLifetime = particleLifetime;
}
float ParticleEmitter::getParticeLifetime() {
    return particleLifetime;
}

void ParticleEmitter::setEmissionRate(float emissionRate) {
    this->emissionRate = emissionRate;
}
float ParticleEmitter::getEmissionRate() {
    return emissionRate;
}

void ParticleEmitter::updateParticle(size_t index, Particle &p, float &lifetime, vec3 &velocity, float dt, void * &userData) {
    // Update the particle information
    lifetime += dt;
    p.x += velocity.x * dt;
    p.y += velocity.y * dt;
    p.z += velocity.z * dt;
}

void ParticleEmitter::deleteUserData(void *data) {
    
}

void ParticleEmitter::update(float dt) {
    for (size_t i = 0; i < particles.size(); i++) {
        // Make sure the particle is still valid
        if (lifetime[i].lifetime > particleLifetime) {
            Particle p = particles[i];
            particlesGridSpace.removeData(vec3(p.x, p.y, p.z), i);
            
            // Remove the particle
            if (particles.size() > 1) {
                particles[i] = particles[particles.size() - 1];
                lifetime[i] = lifetime[lifetime.size() - 1];
                velocity[i] = velocity[velocity.size() - 1];
                
                Particle p = particles[i];
                particlesGridSpace.updateData(vec3(p.x, p.y, p.z), particles.size() - 1, i);
            }
            particles.pop_back();
            lifetime.pop_back();
            velocity.pop_back();
            i--;
            continue;
        }
        
        Particle originalP = particles[i];
        vec3 originalPos = vec3(originalP.x, originalP.y, originalP.z);
        
        updateParticle(i, particles[i], lifetime[i].lifetime, velocity[i], dt, lifetime[i].userData);
        
        Particle updatedP = particles[i];
        vec3 updatePos = vec3(updatedP.x, updatedP.y, updatedP.z);
        particlesGridSpace.updatePosition(originalPos, updatePos, i);
    }
    
    // Create new particles
    float newParticles = dt * emissionRate;
    int integralNewParticles = floor(newParticles);
    if (rand()/ (float)RAND_MAX < newParticles - integralNewParticles) {
        integralNewParticles++;
    }
    
    for (int i = 0; i < integralNewParticles; i++) {
        generateParticle();
    }
}

std::vector<CompleteParticle>* ParticleEmitter::particlesWithinDistance(size_t index, float distance) {
    std::vector<CompleteParticle>* result = new std::vector<CompleteParticle>();
    
    Particle *p = &particles[index];
    std::vector<size_t>* particles = particlesGridSpace.dataWithinDistance(distance, vec3(p->x, p->y, p->z));
    for (int i = 0; i < particles->size(); i++) {
        size_t particleIndex = particles->at(i);
        if (particleIndex != index) {
            CompleteParticle complete;
            
            complete.p = this->particles[particleIndex];
            complete.lifetime = lifetime[particleIndex].lifetime;
            complete.velocity = velocity[particleIndex];
            complete.userData = lifetime[particleIndex].userData;
            
            result->push_back(complete);
        }
    }
    delete particles;
    
    return result;
}

inline float randomFloat() {
    return (float)rand() / (float)RAND_MAX;
}

void ParticleEmitter::updateGeneratedParticle(Particle &p, float &lifetime, vec3 &velocity, vec3 &position, void * &userData) {
    p.x = position.x;
    p.y = position.y;
    p.z = position.z;
    
    p.red = 0.1;
    p.green = 0.4;
    p.blue = 1.0;
    p.alpha = 1.0;
    
    p.diffuseAmount = 1.0;
    
    lifetime = 0.0;
    
    velocity = initialVelocity;
}

void ParticleEmitter::generateParticle() {
    float angle = 2.0 * M_PI * randomFloat();
    float distance = radius * sqrt(randomFloat());
    vec3 pos = vec3(distance * sinf(angle), distance * cosf(angle), 0.0) + getPosition();
    
    Particle p;
    float l;
    vec3 v;
    void *userData;
    updateGeneratedParticle(p, l, v, pos, userData);
    
    particles.push_back(p);
    lifetime.push_back({l, userData});
    velocity.push_back(v);
    particlesGridSpace.insertData(vec3(p.x, p.y, p.z), particles.size() - 1);
}

void ParticleEmitter::draw(const mat4 &projectionTransform) {
    // Update load the data to the GPU
    shared_ptr<Geometry> geo = getGeometry();
    geo->bind();
    glBindBuffer(GL_ARRAY_BUFFER, positionVBO);
    glBufferData(GL_ARRAY_BUFFER, sizeof(Particle) * particles.size(), &particles[0], GL_STREAM_DRAW);
    
    glEnableVertexAttribArray(ParticlePosition);
    glVertexAttribPointer(ParticlePosition, 3, GL_FLOAT, GL_FALSE, sizeof(Particle), 0);
    glVertexAttribDivisor(ParticlePosition, 1);
    
    glEnableVertexAttribArray(ParticleAmbientColor);
    glVertexAttribPointer(ParticleAmbientColor, 4, GL_FLOAT, GL_FALSE, sizeof(Particle), BUFFER_OFFSET(sizeof(GLfloat) * 3));
    glVertexAttribDivisor(ParticleAmbientColor, 1);
    
    glEnableVertexAttribArray(ParticleDiffuseAmount);
    glVertexAttribPointer(ParticleDiffuseAmount, 1, GL_FLOAT, GL_FALSE, sizeof(Particle), BUFFER_OFFSET(sizeof(GLfloat) * 7));
    glVertexAttribDivisor(ParticleDiffuseAmount, 1);
    
    updateWorldTransform();
    shared_ptr<Program> program = getProgram();
    program->useProgram();
    program->loadUniform(ProjectionUniform, projectionTransform);
    program->loadUniform(ModelViewMatrixUniform, worldTransform);
    program->loadUniform(NormalMatrixUniform, normalTransform);
    
    glActiveTexture(GL_TEXTURE0);
    if (tex) {
        tex->bind();
    } else {
        whiteTexture->bind();
    }
    program->loadUniformTexture(TextureUniform, 0);
    
    geo->drawInstancedCount((GLsizei)particles.size());
    geo->unbind();
    glBindBuffer(GL_ARRAY_BUFFER, 0);
    GetGLError();
}
