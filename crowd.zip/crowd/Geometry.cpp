
#define GL_GLEXT_PROTOTYPES

#include <SDL2/SDL_opengl.h>
#include <iostream>
#include "Geometry.h"

#define BUFFER_OFFSET(i) ((char *)NULL + (i))

#if __APPLE__
#define glGenVertexArrays glGenVertexArraysAPPLE
#define glDeleteVertexArrays glDeleteVertexArraysAPPLE
#define glBindVertexArray glBindVertexArrayAPPLE
#endif

Geometry::Geometry() {
    prepared = false;
}
Geometry::~Geometry() {
    if (prepared) {
        glDeleteBuffers(1, &dataBuf);
        glDeleteBuffers(1, &indexBuf);
        glDeleteVertexArrays(1, &vao);
    }
}

Geometry::Geometry(Geometry &geo) {
    prepared = false;
    data = geo.data;
    indicies = geo.indicies;
    
    if (geo.prepared) {
        prepareForRendering();
    }
}

void Geometry::addVertex(vec3 p, vec3 n, vec2 t) {
    if (prepared) {
        std::cout << "VAO cannot be modified after calling prepareForRendering()" << std::endl;
        return;
    }
    
    data.push_back(p.x);
    data.push_back(p.y);
    data.push_back(p.z);
    
    data.push_back(n.x);
    data.push_back(n.y);
    data.push_back(n.z);
    
    data.push_back(t.x);
    data.push_back(t.y);
}

void Geometry::addIndex(int index) {
    if (prepared) {
        std::cout << "VAO cannot be modified after calling prepareForRendering()" << std::endl;
        return;
    }
    
    indicies.push_back(index);
}

void Geometry::prepareForRendering() {
    if (prepared) {
        std::cout << "You cannot call prepareForRendering() multiple times" << std::endl;
        return;
    }
    
    prepared = true;
    
    glGenBuffers(1, &dataBuf);
    glGenBuffers(1, &indexBuf);
    glGenVertexArrays(1, &vao);
    
    glBindVertexArray(vao);
    // Static position data
    glBindBuffer(GL_ARRAY_BUFFER, dataBuf);
    glBufferData(GL_ARRAY_BUFFER, data.size() * sizeof(GLfloat), &data[0], GL_STATIC_DRAW);
    
    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, indexBuf);
    glBufferData(GL_ELEMENT_ARRAY_BUFFER, indicies.size() * sizeof(GLuint), &indicies[0], GL_STATIC_DRAW);
    
    glVertexAttribPointer(PositionAttributeLocation, 3, GL_FLOAT, false, 8*sizeof(GLfloat), BUFFER_OFFSET(0));
    glEnableVertexAttribArray(PositionAttributeLocation);
    glVertexAttribPointer(NormalAttributeLocation, 3, GL_FLOAT, true, 8*sizeof(GLfloat), BUFFER_OFFSET(3 * sizeof(GLfloat)));
    glEnableVertexAttribArray(NormalAttributeLocation);
    glVertexAttribPointer(TexCoordAttributeLocation, 2, GL_FLOAT, false, 8*sizeof(GLfloat), BUFFER_OFFSET(6 * sizeof(GLfloat)));
    glEnableVertexAttribArray(TexCoordAttributeLocation);
    
    glBindVertexArray(0);
    glBindBuffer(GL_ARRAY_BUFFER, 0);
    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, 0);
    
    GetGLError();
}

void Geometry::setVertex(int i, vec3  position, vec3  normal, vec2  textCoord) {
    data[i*8 + 0] = position.x;
    data[i*8 + 1] = position.y;
    data[i*8 + 2] = position.z;
    
    data[i*8 + 3] = normal.x;
    data[i*8 + 4] = normal.y;
    data[i*8 + 5] = normal.z;
    
    data[i*8 + 6] = textCoord.x;
    data[i*8 + 7] = textCoord.y;
}
void Geometry::getVertex(int i, vec3 &position, vec3 &normal, vec2 &textCoord) {
    position.x = data[i*8 + 0];
    position.y = data[i*8 + 1];
    position.z = data[i*8 + 2];
    
    normal.x = data[i*8 + 3];
    normal.y = data[i*8 + 4];
    normal.z = data[i*8 + 5];
    
    textCoord.x = data[i*8 + 6];
    textCoord.y = data[i*8 + 7];
}
void Geometry::flushVertexChanges() {
    
    glBindVertexArray(vao);
    // Static position data
    glBindBuffer(GL_ARRAY_BUFFER, dataBuf);
    glBufferData(GL_ARRAY_BUFFER, data.size() * sizeof(GLfloat), &data[0], GL_STREAM_DRAW);
    
    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, indexBuf);
    
    glVertexAttribPointer(PositionAttributeLocation, 3, GL_FLOAT, false, 8*sizeof(GLfloat), BUFFER_OFFSET(0));
    glEnableVertexAttribArray(PositionAttributeLocation);
    glVertexAttribPointer(NormalAttributeLocation, 3, GL_FLOAT, true, 8*sizeof(GLfloat), BUFFER_OFFSET(3 * sizeof(GLfloat)));
    glEnableVertexAttribArray(NormalAttributeLocation);
    glVertexAttribPointer(TexCoordAttributeLocation, 2, GL_FLOAT, false, 8*sizeof(GLfloat), BUFFER_OFFSET(6 * sizeof(GLfloat)));
    glEnableVertexAttribArray(TexCoordAttributeLocation);
    
    glBindVertexArray(0);
    glBindBuffer(GL_ARRAY_BUFFER, 0);
    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, 0);
}

int Geometry::numberOfVerticies() {
    return (int)data.size() / 8;
}

void Geometry::bind() {
    if (!prepared) {
        std::cout << "You must call prepareForRendering() before trying to render" << std::endl;
        return;
    }
    
    glBindVertexArray(vao);
}

void Geometry::unbind() {
    glBindVertexArray(0);
}

void Geometry::draw() {
    glDrawElements(GL_TRIANGLES, (GLsizei)indicies.size(), GL_UNSIGNED_INT, (void*)0);
}


void Geometry::drawInstancedCount(GLsizei count) {
    glDrawElementsInstanced(GL_TRIANGLES, (GLsizei)indicies.size(), GL_UNSIGNED_INT, (void*)0, count);
}
