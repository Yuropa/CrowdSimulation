
#include <iostream>
#include "Program.h"
#include "glUtil.h"

using namespace std;

Program::Program() {
    name = glCreateProgram();
    builtShaders = false;
    GetGLError();
}
Program::~Program() {
    glDeleteProgram(name);
    name = -1;
}

void Program::bindAttribute(GLint location, string attribute) {
    glBindAttribLocation(name, location, attribute.c_str());
    GetGLError();
}

void Program::buildProgram(string vertexShader, string fragmentShader) {
    if (!createShader(vertexShader, GL_VERTEX_SHADER)) {
        GetGLError();
        return;
    }
    
    if (!createShader(fragmentShader, GL_FRAGMENT_SHADER)) {
        GetGLError();
        return;
    }
    
    if (!linkProgram()) {
        GetGLError();
        return;
    }
    builtShaders = true;
}

bool Program::createShader(string source, GLenum type) {
    GLint logLength, status;
    
    GLuint shader = glCreateShader(type);
    GetGLError();
    const char *cSource = source.c_str();
    glShaderSource(shader, 1, (const GLchar **)&(cSource), NULL);
    GetGLError();
    glCompileShader(shader);
    GetGLError();
    glGetShaderiv(shader, GL_INFO_LOG_LENGTH, &logLength);
    
    if (logLength > 0) {
        GLchar *log = (GLchar*) malloc(logLength);
        glGetShaderInfoLog(shader, logLength, &logLength, log);
        cout << "Shader compile log:" << log << endl;
        free(log);
    }
    
    glGetShaderiv(shader, GL_COMPILE_STATUS, &status);
    if (status == 0) {
        cout << "Failed to compile shader:\n" << source << endl;
        GetGLError();
        return false;
    }
    
    glAttachShader(name, shader);
    
    GetGLError();
    glDeleteShader(shader);
    
    GetGLError();
    
    return true;
}

bool Program::linkProgram() {
    GLint logLength, status;
    
    glLinkProgram(name);
    glGetProgramiv(name, GL_INFO_LOG_LENGTH, &logLength);
    
    if (logLength > 0) {
        GLchar *log = (GLchar*) malloc(logLength);
        glGetProgramInfoLog(name, logLength, &logLength, log);
        cout << "Shader compile log:" << log << endl;
        free(log);
    }
    
    glGetProgramiv(name, GL_LINK_STATUS, &status);
    if (status == 0) {
        cout << "Failed to link program" << endl;
        GetGLError();
        return false;
    }
    
    GetGLError();
    
    return true;
}

void Program::useProgram() {
    if (!builtShaders) {
        cout << "Errors occured while building program. It cannot be used for rendering." << endl;
        GetGLError();
        return;
    }
    
    glUseProgram(name);
}

GLint Program::uniformLocation(std::string uniform) {
    if (!builtShaders) {
        cout << "Errors occured while building program. It cannot be used for rendering." << endl;
        GetGLError();
        return -1;
    }
    
    GLint location;
    std::map<std::string, GLint>::iterator it = uniformMap.find(uniform);
    if (it != uniformMap.end()) {
        location = it->second;
    } else {
        location = glGetUniformLocation(name, uniform.c_str());
        uniformMap.insert(std::pair<std::string, GLint>(uniform, location));
    }
    
    return location;
}

void Program::loadUniform(std::string uniform, const float x) {
    GLint location = uniformLocation(uniform);
    glUniform1f(location, x);
}
void Program::loadUniform(std::string uniform, const vec3 &x) {
    GLint location = uniformLocation(uniform);
    glUniform3f(location, x.x, x.y, x.z);
}
void Program::loadUniform(std::string uniform, const vec4 &x) {
    GLint location = uniformLocation(uniform);
    glUniform4f(location, x.x, x.y, x.z, x.w);
}
void Program::loadUniform(std::string uniform, const mat4 &x) {
    GLint location = uniformLocation(uniform);
    x.loadToUniform(location);
}
void Program::loadUniformTexture(std::string uniform, const int x) {
    GLint location = uniformLocation(uniform);
    glUniform1i(location, x);
}
