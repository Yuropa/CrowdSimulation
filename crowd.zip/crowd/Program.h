
#ifndef Program_H
#define Program_H

#define GL_GLEXT_PROTOTYPES

#include <map>
#include <string>
#include <SDL2/SDL_opengl.h>
#include "Math.h"

class Program;

class Program : public std::enable_shared_from_this<Program> {
    GLuint name;
    bool builtShaders;
    
    bool createShader(std::string source, GLenum type);
    bool linkProgram();
    
    GLint uniformLocation(std::string name);
    std::map<std::string, GLint> uniformMap;
public:
    Program();
    ~Program();
    
    void bindAttribute(GLint location, std::string attribute);
    void buildProgram(std::string vertexShader, std::string fragmentShader);
    void useProgram();
    
    void loadUniform(std::string uniform, const float x);
    void loadUniform(std::string uniform, const vec3 &x);
    void loadUniform(std::string uniform, const vec4 &x);
    void loadUniform(std::string uniform, const mat4 &x);
    void loadUniformTexture(std::string uniform, const int x);
};

#endif /* Program_H */
