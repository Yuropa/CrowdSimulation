
#ifndef VEC4_H
#define VEC4_H

#include <cmath>

class vec4 {
public:
    float x, y, z, w;
    
    inline vec4(float x, float y, float z, float w) {
        this->x = x;
        this->y = y;
        this->z = z;
        this->w = w;
    }
    
    inline vec4(float value)  {
        x = y = z = w = value;
    }
    
    inline vec4() : vec4(0.0) {};
    
    inline vec4 operator+(vec4 vec) const {
        return vec4(x + vec.x, y + vec.y, z + vec.z, w + vec.w);
    }
    
    inline vec4 operator-() const {
        return vec4(-x, -y, -z, -w);
    }
    
    inline vec4 operator-(vec4 vec) const {
        return vec4(x - vec.x, y - vec.y, z - vec.z, w - vec.w);
    }
    
    inline vec4 operator*(vec4 vec) const {
        return vec4(x * vec.x, y * vec.y, z * vec.z, w * vec.w);
    }
    
    inline vec4 operator/(vec4 vec) const {
        return vec4(x / vec.x, y / vec.y, z / vec.z, w / vec.w);
    }
    
    inline float dot(vec4 vec) const {
        return x*vec.x + y*vec.y + z*vec.z + w*vec.w;
    }
    
    inline float length() const {
        return sqrtf(dot(*this));
    }
    
    inline vec4 normalize() const {
        float l = length();
        return vec4(x/l, y/l, z/l, w/l);
    }
    
    inline float distanceTo(vec4 v) const {
        return (v - *this).length();
    }
    
    inline vec4 lerp(vec4 end, float t) {
        return *this * (1.0 - t) + end * t;
    }
};

inline vec4 operator/(vec4 v, float a) {
    return vec4(v.x/a, v.y/a, v.z/a, v.w/a);
}

inline vec4 operator*(vec4 v, float a) {
    return vec4(v.x*a, v.y*a, v.z*a, v.w*a);
}

inline vec4 operator*(float a, vec4 v) {
    return vec4(v.x*a, v.y*a, v.z*a, v.w*a);
}

#endif