
#include "Sphere.h"
#include "Ball.h"

#define STRINGIFY(x) #x
const std::string vertexShader =
STRINGIFY(
          uniform mat4 u_modelView;
          uniform mat4 u_normal;
          uniform mat4 u_projection;
          
          attribute vec3 a_position;
          attribute vec3 a_normal;
          attribute vec2 a_texCoord;
          
          varying vec3 v_position;
          varying vec3 v_normal;
          void main() {
              v_normal = (u_normal * vec4(a_normal, 0.0)).xyz;
              vec4 pos = u_modelView * vec4(a_position, 1.0);
              v_position = pos.xyz;
              gl_Position = u_projection * pos;
          }
          );
const std::string fragmentShader =
STRINGIFY(
          uniform sampler2D u_tex;
          
          varying vec3 v_position;
          varying vec3 v_normal;
          void main() {
              vec3 l = normalize(vec3(100.0, -100.0, 100.0) - v_position);
              vec4 diffuse = vec4(1.0, 0.3, 0.2, 1.0) * (max(dot(v_normal, l), 0.0));
              vec4 ambient = vec4(0.3, 0.1, 0.1, 1.0);
              gl_FragColor = clamp(diffuse + ambient, 0.0, 1.0);
          }
          );

Ball::Ball(float radius) {
    this->radius = radius;
    
    shared_ptr<Program> program = shared_ptr<Program>(new Program());
    program->buildProgram(vertexShader, fragmentShader);
    setProgram(program);
    
    setGeometry(shared_ptr<Sphere>(new Sphere(radius, 20, 20)));
}

float Ball::getRadius() {
    return radius;
}
