
#include <queue>
#include "Node.h"
#include "OpenGL/OpenGL.h"

Node::Node() {
    children = vector<shared_ptr<Node>>();
    needsLocalTransformUpdate = true;
    position = vec3(0.0);
    rotation = vec3(0.0);
    scale = vec3(1.0);
    enabled = true;
    acceleration = vec3(0.0);
    velocity = vec3(0.0);
    
    prog = nullptr;
    geo = nullptr;
}
Node::~Node() {
    
}

void Node::addChildNode(shared_ptr<Node> n) {
    n->removeFromParent();
    children.push_back(n);
    n->parent = shared_from_this();
}
void Node::removeFromParent() {
    if (parent) {
        shared_ptr<Node> p = parent;
        parent = shared_ptr<Node>();
        p->children.erase(remove(p->children.begin(), p->children.end(), shared_from_this()), p->children.end());
    }
}

void Node::removeAllChildren() {
    for (int i = (int)children.size() - 1; i >= 0; i--) {
        shared_ptr<Node> child = children[i];
        child->removeFromParent();
    }
}

shared_ptr<Node> Node::childWithName(std::string name) {
    queue<shared_ptr<Node>> nodeQueue;
    nodeQueue.push(shared_from_this());
    
    while (!nodeQueue.empty()) {
        shared_ptr<Node> n = nodeQueue.front();
        nodeQueue.pop();
        
        if (n->name.compare(name) == 0) {
            return n;
        } else {
            for (int i = 0; i < n->children.size(); i++) {
                nodeQueue.push(n->children[i]);
            }
        }
    }
    
    return shared_ptr<Node>();
}

void Node::updateLocalTransform() {
    if (needsLocalTransformUpdate) {
        mat4 translationMtx, rotationXMtx, rotationYMtx, rotationZMtx, scaleMtx;
        translationMtx = mat4::translation(position);
        rotationXMtx = mat4::xRotation(rotation.x);
        rotationYMtx = mat4::yRotation(rotation.y);
        rotationZMtx = mat4::zRotation(rotation.z);
        scaleMtx = mat4::scale(scale);
        
        localTransform = scaleMtx * rotationZMtx * rotationYMtx * rotationXMtx * translationMtx;
        
        needsLocalTransformUpdate = false;
    }
}

void Node::updateWorldTransform() {
    updateLocalTransform();
    
    if (needsWorldTransformUpdate) {
        if (parent) {
            worldTransform = parent->getWorldTransform() * localTransform;
        } else {
            worldTransform = localTransform;
        }
        normalTransform = worldTransform.invert().transpose();
        needsWorldTransformUpdate = false;
    }
}

void Node::setNeedsWorldTransformUpdate() {
    needsWorldTransformUpdate = true;
    
    for (int i = 0; i < children.size(); i++) {
        children[i]->setNeedsWorldTransformUpdate();
    }
}

void Node::translateBy(vec3 translation) {
    position = position + translation;
    needsLocalTransformUpdate = true;
    setNeedsWorldTransformUpdate();
}
void Node::translateTo(vec3 translation) {
    position = translation;
    needsLocalTransformUpdate = true;
    setNeedsWorldTransformUpdate();
}
vec3 Node::getPosition() {
    return position;
}

void Node::scaleBy(vec3 scale) {
    this->scale = this->scale * scale;
    needsLocalTransformUpdate = true;
    setNeedsWorldTransformUpdate();
}
void Node::scaleTo(vec3 scale) {
    this->scale = scale;
    needsLocalTransformUpdate = true;
    setNeedsWorldTransformUpdate();
}
vec3 Node::getScale() {
    return scale;
}

void Node::rotateBy(vec3 rotation) {
    this->rotation = this->rotation + rotation;
    needsLocalTransformUpdate = true;
    setNeedsWorldTransformUpdate();
}
void Node::rotateTo(vec3 rotation) {
    this->rotation = rotation;
    needsLocalTransformUpdate = true;
    setNeedsWorldTransformUpdate();
}
vec3 Node::getRotation() {
    return rotation;
}

void Node::setEnabled(bool enable) {
    this->enabled = enable;
}
bool Node::isEnabled() {
    return enabled;
}

void Node::setGeometry(shared_ptr<Geometry> geometry) {
    geo = geometry;
}
shared_ptr<Geometry> Node::getGeometry() {
    return geo;
}

void Node::setProgram(shared_ptr<Program> program) {
    prog = program;
}
shared_ptr<Program> Node::getProgram() {
    return prog;
}

void Node::setTexture(shared_ptr<Texture> tex) {
    this->tex = tex;
}
shared_ptr<Texture> Node::getTexture() {
    return tex;
}

void Node::update(float dt) {
    for (int i = 0; i < children.size(); i++) {
        children[i]->update(dt);
    }
}

void Node::draw(const mat4 &projectionTransform) {
    if (!enabled) {
        return;
    }
    
    updateWorldTransform();
    
    if (prog) {
        prog->useProgram();
        prog->loadUniform(ProjectionUniform, projectionTransform);
        prog->loadUniform(ModelViewMatrixUniform, worldTransform);
        prog->loadUniform(NormalMatrixUniform, normalTransform);
        if (tex) {
            glActiveTexture(GL_TEXTURE0);
            tex->bind();
            prog->loadUniformTexture(TextureUniform, 0);
        } else {
            glBindTexture(GL_TEXTURE_2D, 0);
        }
    } else {
        glUseProgram(0);
    }
    
    if (geo) {
        geo->bind();
        
        geo->draw();
        geo->unbind();
    }
    
    for (int i = 0; i < children.size(); i++) {
        children[i]->draw(projectionTransform);
    }
}

mat4 Node::getWorldTransform() {
    updateLocalTransform();
    updateWorldTransform();
    return worldTransform;
}
