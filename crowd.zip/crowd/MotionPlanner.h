
#ifndef MotionPlanner_hpp
#define MotionPlanner_hpp

#include "Node.h"

class MotionObstacle;
class MotionObstacle : public enable_shared_from_this<MotionObstacle> {
public:
    virtual vec2 getPosition();
    virtual shared_ptr<Geometry> getGeometry();
    virtual bool containsPoint(vec2 point);
    virtual bool intersectLineSegment(vec2 start, vec2 end);
    virtual void addExtent(float radius);
    virtual vec2 projectPoint(vec2 point, float radius);
};

class CircleObstacle : public MotionObstacle {
    float radius;
    vec2 position;
public:
    CircleObstacle(vec2 position, float radius);
    
    float getRadius();
    virtual vec2 getPosition();
    
    virtual shared_ptr<Geometry> getGeometry();
    virtual bool containsPoint(vec2 point);
    virtual bool intersectLineSegment(vec2 start, vec2 end);
    virtual void addExtent(float radius);
    virtual vec2 projectPoint(vec2 point, float radius);
};

class CapsuleObstacle : public MotionObstacle {
    float radius;
    vec2 start, end;
public:
    CapsuleObstacle(vec2 startPosition, vec2 endPosition, float radius);
    
    float getRadius();
    virtual vec2 getPosition();
    vec2 getStartPosition();
    vec2 getEndPosition();
    
    virtual shared_ptr<Geometry> getGeometry();
    virtual bool containsPoint(vec2 point);
    virtual bool intersectLineSegment(vec2 start, vec2 end);
    virtual void addExtent(float radius);
    virtual vec2 projectPoint(vec2 point, float radius);
};

struct PathNode {
    int node;
    vec2 position;
    struct PathNode *parent;
    float cost;
    float heristic;
    float costToNode(PathNode *node) {
        return position.distanceTo(node->position);
    }
};

struct PathNodeCompare {
    bool operator() (PathNode *i, PathNode *j) {
        return i->cost < j->cost;
    }
};

class MotionPlanner : public Node {
    float width, height;
    shared_ptr<Node> endIndicator;
    
    class LineSegment {
    public:
        vec2 start, end;
        LineSegment(vec2 start, vec2 end) {
            this->start = start;
            this->end = end;
        }
    };
    
    vector<PathNode> waypoints;
    map<int, vector<int>*> connections;
    
    vector<shared_ptr<MotionObstacle>> obsticals;
    bool showDebug;
    bool routePlanned;
    
    shared_ptr<Program> obstalProgram;
    
    shared_ptr<Texture> waypointTexture;
    shared_ptr<Program> waypointProgram;
    shared_ptr<Geometry> waypointGeometry;
    
    vector<shared_ptr<Node>> agents;
    vector<vector<vec2>> targetWaypoints;
    
    void planRouteForAgent(int index);
    void updateAgent(float dt, int index);
public:
    MotionPlanner(float width, float height);
    
    float getHeight();
    float getWidth();
    
    void addAgent(vec2 pos);
    void setEndPosition(vec2 pos);
    vec2 getEndPosition();
    void addObstacle(shared_ptr<MotionObstacle> obstacle);
    
    void generateRoute();
    
    void setEnableDebug(bool flag);
    bool enableDebug();
    
    virtual void update(float dt);
    virtual void draw(const mat4 &projectionTransform);
};

#endif /* MotionPlanner_hpp */
