
#ifndef ShallowWater_hpp
#define ShallowWater_hpp

#include "Node.h"

class ShallowWater : public Node {
    vec3 size;
    int segments;
    
    std::vector<float> h;
    std::vector<float> uh;
    std::vector<float> mid_h;
    std::vector<float> mid_uh;
    
    void waterUpdate(float dt);
    void updateGeometry();
public:
    ShallowWater(vec3 size, int segments);
    
    vec3 getSize();
    int getSegments();
    
    virtual void update(float dt);
};

#endif /* ShallowWater_hpp */
