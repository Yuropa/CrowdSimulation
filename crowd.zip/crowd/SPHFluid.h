
#ifndef SPHFluid_hpp
#define SPHFluid_hpp

#include "Node.h"

typedef struct {
    GLfloat x, y, z;
} SPHRenderParticle;

typedef struct {
    float density;
    float pressure;
    vec3 position;
    vec3 velocity;
    vec3 oldPos;
} SPHParticle;

class SPHFluid : public Node {
    vec3 emitterPosition;
    vec3 boundSize;
    
    GLuint positionVBO;
    vector<SPHRenderParticle> renderParticles;
    vector<SPHParticle> particles;
    
    void particlesUpdate(float dt);
public:
    SPHFluid(vec3 emitterPosition, vec3 boundSize);
    ~SPHFluid();
    
    vec3 getEmitterPosition();
    vec3 getBoundsSize();
    float getRemainingEmitterDuration();
    
    virtual void update(float dt);
    virtual void draw(const mat4 &projectionTransform);
};

#endif /* SPHFluid_hpp */
